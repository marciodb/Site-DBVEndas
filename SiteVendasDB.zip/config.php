<?php

/**
 * The base MySQL settings of Osclass
 */
define('MULTISITE', 0);

/** MySQL database name for Osclass */
define('DB_NAME', 'id5617942_dbvendas');

/** MySQL database username */
define('DB_USER', 'id5617942_dbserver');

/** MySQL database password */
define('DB_PASSWORD', '051080');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Table prefix */
define('DB_TABLE_PREFIX', 'oc_');

define('REL_WEB_URL', '/');

define('WEB_PATH', 'https://teste-marcio.000webhostapp.com/');

?>